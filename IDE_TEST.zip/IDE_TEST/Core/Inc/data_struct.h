/*
 * data_struct.h
 *
 *  Created on: May 30, 2024
 *      Author: Thanh Dat
 */

#ifndef INC_DATA_STRUCT_H_
#define INC_DATA_STRUCT_H_

struct vel_data {
	float v, w;
};
extern struct vel_data vel_data_rx;
extern struct vel_data vel_data_tx;



#endif /* INC_DATA_STRUCT_H_ */
