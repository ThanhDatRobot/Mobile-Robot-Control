/*
 * mainpp.h
 *
 *  Created on: May 30, 2024
 *      Author: Thanh Dat
 */

#ifndef INC_MAINPP_H_
#define INC_MAINPP_H_

#ifdef __cplusplus
 extern "C" {
#endif

void setup(void);
void loop(void);

#ifdef __cplusplus
}
#endif


#endif /* INC_MAINPP_H_ */
