/*
 * mainpp.cpp
 *
 *  Created on: May 30, 2024
 *      Author: Thanh Dat
 */

#include <mainpp.h>
#include <ros.h>
#include <std_msgs/Empty.h>
#include "std_msgs/Int32.h"
#include <std_msgs/String.h>
#include <std_msgs/Float64.h>
#include <geometry_msgs/Twist.h>
#include <data_struct.h>

float speed_wish;
extern float v_L_ref, v_R_ref;
extern float v_L, v_R;
extern float wheel_base;


// Node:
ros::NodeHandle nh; // default 25, 25, 512, 512;

geometry_msgs::Twist vel_msg;
uint32_t nowTick = 0;
uint32_t pastTick = 0;

void subscriber_cmd_callback(const geometry_msgs::Twist& data);


//// Publisher:
ros::Publisher vel_pub("vel_pub", &vel_msg);

// Subscriber:
ros::Subscriber<geometry_msgs::Twist> vel_sub("cmd_vel", &subscriber_cmd_callback);

void HAL_UART_TxCpltCallback(UART_HandleTypeDef *huart){
	if(huart->Instance == USART3)
		nh.getHardware()->flush();
}

void HAL_UART_RxCpltCallback(UART_HandleTypeDef *huart){
	if(huart->Instance == USART3)
		nh.getHardware()->reset_rbuf();
}

// Setup node:
void setup()
{
	nh.initNode();
	nh.subscribe(vel_sub);
	nh.advertise(vel_pub);
}

// Loop:
void loop()
{
	nowTick = HAL_GetTick();
	if(nowTick - pastTick > 100)
	{
		vel_msg.linear.x  = vel_data_tx.v;
		vel_msg.angular.z = vel_data_tx.w;
		vel_pub.publish(&vel_msg);
		pastTick = nowTick;
	}
	nh.spinOnce();
}

void subscriber_cmd_callback(const geometry_msgs::Twist& data){
	vel_data_rx.v = data.linear.x;
	vel_data_rx.w = data.angular.z;
}


